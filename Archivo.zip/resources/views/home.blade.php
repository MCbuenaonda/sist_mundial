@extends('layouts.app')

@section('content')
<div class="px-5">
    <pagina-inicio></pagina-inicio>
</div>
@endsection
