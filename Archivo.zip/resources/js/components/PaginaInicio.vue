<template>
    <div>
        <router-view></router-view>
    </div>
</template>

<script>
    import store from '../store';

    export default {
        store,
        mounted() {}
    }
</script>
