<?php

namespace App\Http\Controllers;

use App\CincoEquipo;
use Illuminate\Http\Request;

class CincoEquipoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CincoEquipo  $cincoEquipo
     * @return \Illuminate\Http\Response
     */
    public function show(CincoEquipo $cincoEquipo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CincoEquipo  $cincoEquipo
     * @return \Illuminate\Http\Response
     */
    public function edit(CincoEquipo $cincoEquipo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CincoEquipo  $cincoEquipo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CincoEquipo $cincoEquipo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CincoEquipo  $cincoEquipo
     * @return \Illuminate\Http\Response
     */
    public function destroy(CincoEquipo $cincoEquipo)
    {
        //
    }
}
