<?php

namespace App\Http\Controllers;

use App\Conmebol;
use Illuminate\Http\Request;

class ConmebolController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return 'ConmebolController';
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Conmebol  $conmebol
     * @return \Illuminate\Http\Response
     */
    public function show(Conmebol $conmebol)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Conmebol  $conmebol
     * @return \Illuminate\Http\Response
     */
    public function edit(Conmebol $conmebol)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Conmebol  $conmebol
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Conmebol $conmebol)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Conmebol  $conmebol
     * @return \Illuminate\Http\Response
     */
    public function destroy(Conmebol $conmebol)
    {
        //
    }
}
