<?php

namespace App\Http\Controllers;

use App\TresEquipo;
use Illuminate\Http\Request;

class TresEquipoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TresEquipo  $tresEquipo
     * @return \Illuminate\Http\Response
     */
    public function show(TresEquipo $tresEquipo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TresEquipo  $tresEquipo
     * @return \Illuminate\Http\Response
     */
    public function edit(TresEquipo $tresEquipo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TresEquipo  $tresEquipo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TresEquipo $tresEquipo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TresEquipo  $tresEquipo
     * @return \Illuminate\Http\Response
     */
    public function destroy(TresEquipo $tresEquipo)
    {
        //
    }
}
