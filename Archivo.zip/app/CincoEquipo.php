<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CincoEquipo extends Model
{
    //
}
