<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CuatroEquipo extends Model
{
    //
}
