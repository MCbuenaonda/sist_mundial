<?php

namespace App\Resources;

use Illuminate\Http\Request;

class MundialConstants {
    public $true = 1;
    public $false = 0;
    public $desc = 'DESC';
    public $asc = 'ASC';
}
