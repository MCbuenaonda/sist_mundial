<?php $__env->startSection('content'); ?>
    <div class="mx-5 justify-content-center">
        <h2 class="mt-2 main-title"><?php echo e($mundial->id); ?>ª Copa del Mundo - <?php echo e($mundial->pais->nombre); ?> <?php echo e($mundial->anio); ?></h2>
        <hr>

        <section>
            <div class="clearfix container">
                <?php if($anterior): ?>
                    <div class="text-center float-left">
                        <h2 class="bg-sky text-white">Partido anterior</h2>
                        <div class="clearfix">
                            <small class="float-left">Fase <?php echo e($anterior->fase_id); ?></small>
                            <small class="float-right">Grupo <?php echo e($anterior->grupo->nombre); ?></small>
                        </div>
                        <h5><?php echo e($anterior->fecha); ?></h5>
                        <h4>Estadio <?php echo e($anterior->ciudad->estadio); ?> <?php echo e($anterior->ciudad->nombre); ?>, <?php echo e($anterior->paisL->siglas); ?></h4>
                        <h3><?php echo e($anterior->paisL->nombre); ?> <?php echo e($anterior->gol_l); ?> - <?php echo e($anterior->gol_v); ?> <?php echo e($anterior->paisV->nombre); ?></h3>
                    </div>
                <?php endif; ?>

                <div class="text-center float-right">
                    <h2 class="bg-sky text-white">Proximo partido</h2>
                    <div class="clearfix">
                        <small class="float-left">Fase <?php echo e($juego->fase_id); ?></small>
                        <small class="float-right">Grupo <?php echo e($juego->grupo->nombre); ?></small>
                    </div>
                    <h5><?php echo e($juego->fecha); ?></h5>
                    <h4>Estadio <?php echo e($juego->ciudad->estadio); ?> <?php echo e($juego->ciudad->nombre); ?>, <?php echo e($juego->paisL->siglas); ?></h4>
                    <h3><?php echo e($juego->paisL->nombre); ?> - <?php echo e($juego->paisV->nombre); ?></h3>
                    <a href="<?php echo e(route('mundial.jugar', ['partido' => $juego->id])); ?>" class="btn btn-success">Jugar</a>
                </div>
            </div>
        </section>

        <section>
            <div class="row mt-5">
                <?php $__currentLoopData = $confederaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confederacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $name = strtolower($confederacion->nombre);
                ?>
                <div class="col-4">
                    <a href="<?php echo e(route( 'confederacion.index', ['confederacion' => $confederacion->id] )); ?>">
                        <confederacion-card confederacion="<?php echo e($confederacion); ?>"></confederacion-card>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emmanuel/Sites/laravel/mundial/resources/views/mundial/index.blade.php ENDPATH**/ ?>