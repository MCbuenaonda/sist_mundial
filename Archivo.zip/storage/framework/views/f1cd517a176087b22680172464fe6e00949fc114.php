<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mt-2 main-title"><?php echo e($confederacion->nombre); ?></h2>
        <hr>

        <section>
            <div class="row mt-5">
                <div class="col-md-4">
                    <div class="card country <?php echo e(strtolower($confederacion->paisRankinMundial->siglas)); ?>">
                        <div class="card-body text-white animate__animated animate__fadeIn">
                          <h2 class="card-title"><?php echo e($confederacion->paisRankinMundial->nombre); ?></h2>
                        </div>
                    </div>
                    <p class="conf-stats">Mejor posicion rankin mundial</p>
                </div>
                <div class="col-md-4">
                    <div class="card country <?php echo e(strtolower($confederacion->paisPuntosFase->pais->siglas)); ?>">
                        <div class="card-body text-white animate__animated animate__fadeIn">
                          <h2 class="card-title"><?php echo e($confederacion->paisPuntosFase->pais->nombre); ?></h2>
                        </div>
                    </div>
                    <p class="conf-stats">Mejor posicion rankin confederacion</p>
                </div>
                <div class="col-md-4">
                    <div class="card country <?php echo e(strtolower($confederacion->PaisMasGoles->pais->siglas)); ?>">
                        <div class="card-body text-white animate__animated animate__fadeIn">
                          <h2 class="card-title"><?php echo e($confederacion->PaisMasGoles->pais->nombre); ?></h2>
                          <h2><small><?php echo e($confederacion->PaisMasGoles->gf); ?> Goles</small></h2>
                        </div>
                    </div>
                    <p class="conf-stats">Mas goleador</p>
                </div>
            </div>
        </section>


        <section>
            <?php $grupoId = 0; ?>

            <h2 class="text-sky mt-5"><?php echo e($confederacion->paisesFase[0]->faseConfederacion->fase->nombre); ?></h2>
            <hr>

            <?php $__currentLoopData = $confederacion->paisesFase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($data->grupo_id != $grupoId): ?>
                    <?php if($key > 0): ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                    <h4 class="mt-5">Grupo <?php echo e($data->grupo->nombre); ?></h4>

                    <table class="table table-hover table-sm">
                        <thead class="table-head">
                            <tr>
                                <th>Pais</th>
                                <th>Puntos</th>
                                <th>JJ</th>
                                <th>JG</th>
                                <th>JE</th>
                                <th>JP</th>
                                <th>GF</th>
                                <th>GC</th>
                            </tr>
                        </thead>
                        <tbody>

                    <?php $grupoId = $data->grupo_id ?>
                <?php endif; ?>

                <tr>
                    <td scope="row">
                        <img src="/images/fifa/32/<?php echo e($data->pais->nombre); ?>.png" alt="">
                        <?php echo e($data->pais->nombre); ?>

                    </td>
                    <td><?php echo e($data->puntos); ?></td>
                    <td><?php echo e($data->jj); ?></td>
                    <td><?php echo e($data->jg); ?></td>
                    <td><?php echo e($data->je); ?></td>
                    <td><?php echo e($data->jp); ?></td>
                    <td><?php echo e($data->gf); ?></td>
                    <td><?php echo e($data->gc); ?></td>
                </tr>
                

                 <?php if( (count($confederacion->paisesFase) - 1) == $key): ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <section>
            <h3 class="text-sky mt-5">Paises pertenecientes a la confederacion</h3>
            <hr>

            <div class="row my-5">
                <?php $__currentLoopData = $confederacion->paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-3">
                        <div class="animate__animated animate__fadeIn card text-left mb-5 shadow card-pais text-center">
                            <img class="card-img-sm" src="/images/fifa/128/<?php echo e($pais->nombre); ?>.png" alt="Card image cap">
                            <div class="animate__animated animate__fadeIn label-pais">
                                <h3 class="font-weight-bold"><?php echo e($pais->nombre); ?></h3>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emmanuel/Sites/laravel/mundial/resources/views/confederacion/index.blade.php ENDPATH**/ ?>