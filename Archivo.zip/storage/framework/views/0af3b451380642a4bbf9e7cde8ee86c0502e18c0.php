<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mt-2 main-title"><?php echo e($confederacion->nombre); ?></h2>
        <hr>
        <div class="row mt-5">
            <div class="col-12">
                <ul>
                    <?php $__currentLoopData = $uefa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($pais->pais->nombre); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emmanuel/Sites/laravel/mundial/resources/views/uefa/index.blade.php ENDPATH**/ ?>