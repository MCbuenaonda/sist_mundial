<?php $__env->startSection('content'); ?>
<div class="px-5">
    <pagina-inicio></pagina-inicio>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/emmanuel/Sites/laravel/mundial/resources/views/home.blade.php ENDPATH**/ ?>